# hotel


Frontend has been build from  Bootstrap template.
Database connection to MariaDB made with PHP.
Also used much of Bootstrap, HTML, CSS and PHP while modifying Frontend.

**INSTALLING**

1) Extract all files from archive to _C:\xampp\htdocs\hotel_.
2) Open XAMPP control panel and activate apache and MySQL.
3) Open MySQL admin interface and import _hotel.sql_.
4) Edit _classes/DB.php_ line 5 and put your MySQL username and password there if you have changed it after installing XAMPP.
5) Open web browser url 
_http://localhost/hotel_.

**ISSUES**

Please report ALL issues on our official pages below:

Github 

https://github.com/hhdigiproj18/hotel/

**FEEDBACK**

Please send feedback to:

_tim.fabritius@myy.haaga-helia.fi_

or report them as issue on Github

We don't have database host yet but we will take it soon!


**CREDITS**

Thanks Viththiyakaran Nadarajah for template.
https://www.youtube.com/watch?v=MxOZ6AfcUeU&t=1s
